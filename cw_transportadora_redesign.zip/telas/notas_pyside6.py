"""
Tela de Notas Importadas - CW Transportadora v8
Migrado de Tkinter/CustomTkinter para PySide6.

Layout dividido em dois painéis:
  • Esquerda  – lista de manifestos + botões Importar / Apagar
  • Direita   – tabela de notas do manifesto selecionado + resumo
A importação roda em thread de fundo e retorna via Signal.
"""

from __future__ import annotations

import threading
from datetime import datetime

from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QLabel, QListWidget, QListWidgetItem,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QFrame, QFileDialog, QMessageBox, QAbstractItemView,
    QSizePolicy,
)

from services.notas_service import notas_service
from telas.theme_pyside6 import theme_manager, AccentColor
from utils.components import ModernButton, ButtonStyle, ModernCard
from utils.helpers import formatar_moeda, formatar_peso
from utils.logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Constantes de coluna da tabela de notas
# ---------------------------------------------------------------------------
_COL_CTE       = 0
_COL_REMETENTE = 1
_COL_DEST      = 2
_COL_ORIGEM    = 3
_COL_DESTINO   = 4
_COL_FRETE     = 5
_COL_PESO      = 6
_COL_STATUS    = 7

_COLUNAS_NOTAS = ["CT-e", "Remetente", "Destinatário", "Origem", "Destino", "Frete", "Peso", "Status"]


# ---------------------------------------------------------------------------
# Worker de importação – emite sinal quando concluída
# ---------------------------------------------------------------------------
class _ImportWorker(QObject):
    """Executa a importação em thread separada e emite sinais thread-safe."""

    concluido = Signal(dict)       # resultado da importação
    erro      = Signal(str)        # mensagem de erro

    def __init__(self, caminho: str):
        super().__init__()
        self._caminho = caminho

    def run(self):
        try:
            resultado = notas_service.importar_manifesto(self._caminho)
            self.concluido.emit(resultado)
        except Exception as exc:
            logger.error(f"Erro ao importar manifesto: {exc}")
            self.erro.emit(str(exc))


# ---------------------------------------------------------------------------
# Tela principal
# ---------------------------------------------------------------------------
class TelaNotas(QWidget):
    """Tela de gerenciamento de manifestos e notas importadas (PySide6)."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)

        # Mapeamento item-da-lista → manifesto_id
        self._manifesto_ids: dict[int, int] = {}   # row → manifesto_id

        self._setup_ui()
        self._carregar_manifestos()

    # ------------------------------------------------------------------
    # Construção da interface
    # ------------------------------------------------------------------

    def _setup_ui(self) -> None:
        colors  = theme_manager.colors
        tokens  = theme_manager.tokens

        self.setStyleSheet(f"background-color: {colors['bg_primary']};")

        root = QVBoxLayout(self)
        root.setContentsMargins(
            tokens.SPACING_2XL, tokens.SPACING_2XL,
            tokens.SPACING_2XL, tokens.SPACING_2XL,
        )
        root.setSpacing(tokens.SPACING_LG)

        # ── Resumo / totais ─────────────────────────────────────────
        self._lbl_resumo = QLabel("Selecione um manifesto para visualizar as notas.")
        self._lbl_resumo.setFont(theme_manager.get_font(tokens.FONT_SIZE_MD, bold=True))
        self._lbl_resumo.setStyleSheet(
            f"color: {colors['text_secondary']}; background-color: transparent;"
        )
        self._lbl_resumo.setWordWrap(True)
        root.addWidget(self._lbl_resumo)

        # ── Splitter: esquerda=manifestos / direita=notas ────────────
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet(f"""
        QSplitter::handle {{
            background-color: {colors['border_subtle']};
        }}
        """)

        splitter.addWidget(self._criar_painel_manifestos())
        splitter.addWidget(self._criar_painel_notas())
        splitter.setStretchFactor(0, 0)   # esquerda – tamanho fixo preferido
        splitter.setStretchFactor(1, 1)   # direita  – cresce com a janela
        splitter.setSizes([340, 900])

        root.addWidget(splitter, stretch=1)

    # ── Painel esquerdo – Manifestos ─────────────────────────────────────

    def _criar_painel_manifestos(self) -> QWidget:
        colors = theme_manager.colors
        tokens = theme_manager.tokens

        card = ModernCard("📁 Manifestos", parent=self)
        card.setMinimumWidth(280)
        card.setMaximumWidth(400)

        # Botões de ação
        btn_row = QHBoxLayout()
        btn_row.setSpacing(tokens.SPACING_SM)

        self._btn_importar = ModernButton("＋ Importar Manifesto", ButtonStyle.SUCCESS)
        self._btn_importar.clicked.connect(self._importar_manifesto)
        btn_row.addWidget(self._btn_importar, stretch=1)

        self._btn_apagar = ModernButton("Apagar", ButtonStyle.DANGER)
        self._btn_apagar.clicked.connect(self._apagar_manifesto)
        btn_row.addWidget(self._btn_apagar)

        card.add_layout(btn_row)

        # Lista de manifestos
        self._lista_manifestos = QListWidget()
        self._lista_manifestos.setAlternatingRowColors(True)
        self._lista_manifestos.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._lista_manifestos.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._lista_manifestos.setStyleSheet(f"""
        QListWidget {{
            background-color: {colors['bg_secondary']};
            border: 1px solid {colors['border_subtle']};
            border-radius: {tokens.RADIUS_MD}px;
            outline: none;
            font-size: {tokens.FONT_SIZE_MD}px;
            color: {colors['text_primary']};
        }}
        QListWidget::item {{
            padding: {tokens.SPACING_SM}px {tokens.SPACING_MD}px;
            border-bottom: 1px solid {colors['border_subtle']};
        }}
        QListWidget::item:hover {{
            background-color: {colors['table_row_hover']};
        }}
        QListWidget::item:selected {{
            background-color: {colors['table_row_selected']};
            color: {colors['text_primary']};
        }}
        """)
        self._lista_manifestos.currentRowChanged.connect(self._ao_selecionar_manifesto)
        card.add_widget(self._lista_manifestos)

        return card

    # ── Painel direito – Notas ───────────────────────────────────────────

    def _criar_painel_notas(self) -> QWidget:
        colors = theme_manager.colors
        tokens = theme_manager.tokens

        card = ModernCard("📄 Notas do Manifesto Selecionado", parent=self)

        # Tabela de notas
        self._tabela_notas = QTableWidget(0, len(_COLUNAS_NOTAS))
        self._tabela_notas.setHorizontalHeaderLabels(_COLUNAS_NOTAS)
        self._tabela_notas.setAlternatingRowColors(True)
        self._tabela_notas.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._tabela_notas.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._tabela_notas.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._tabela_notas.verticalHeader().setVisible(False)
        self._tabela_notas.setSortingEnabled(True)
        self._tabela_notas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        hdr = self._tabela_notas.horizontalHeader()
        # CT-e: stretch; demais: ajuste ao conteúdo ou dimensão mínima fixa
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(False)
        # Larguras iniciais
        larguras = [160, 220, 220, 130, 130, 110, 110, 110]
        for col, w in enumerate(larguras):
            self._tabela_notas.setColumnWidth(col, w)

        self._tabela_notas.setStyleSheet(f"""
        QTableWidget {{
            background-color: {colors['bg_secondary']};
            alternate-background-color: {colors['table_row_odd']};
            gridline-color: {colors['border_subtle']};
            border: 1px solid {colors['border_subtle']};
            border-radius: {tokens.RADIUS_LG}px;
            selection-background-color: {colors['table_row_selected']};
            selection-color: {colors['text_primary']};
            outline: none;
            font-size: {tokens.FONT_SIZE_MD}px;
            color: {colors['text_primary']};
        }}
        QTableWidget::item {{
            padding: 8px 12px;
            border-bottom: 1px solid {colors['border_subtle']};
        }}
        QTableWidget::item:hover {{
            background-color: {colors['table_row_hover']};
        }}
        QHeaderView::section {{
            background-color: {colors['table_header_bg']};
            color: {colors['table_header_text']};
            padding: 10px 12px;
            border: none;
            border-bottom: 2px solid {colors['border_default']};
            border-right: 1px solid {colors['border_subtle']};
            font-weight: 700;
            font-size: {tokens.FONT_SIZE_SM}px;
        }}
        """)

        card.add_widget(self._tabela_notas)
        return card

    # ------------------------------------------------------------------
    # Carregar manifestos
    # ------------------------------------------------------------------

    def _carregar_manifestos(self) -> None:
        self._lista_manifestos.blockSignals(True)
        self._lista_manifestos.clear()
        self._manifesto_ids.clear()

        try:
            manifestos = notas_service.listar_manifestos("Geral", None, None)
        except Exception as exc:
            logger.error(f"Erro ao listar manifestos: {exc}")
            manifestos = []

        for row, manifesto in enumerate(manifestos):
            manifesto_id, nome_arquivo, data_importacao, total_notas, *_rest = manifesto
            texto = f"📁 {nome_arquivo}\n{total_notas} nota(s)  •  {data_importacao or ''}"
            item = QListWidgetItem(texto)
            self._lista_manifestos.addItem(item)
            self._manifesto_ids[row] = manifesto_id

        self._lista_manifestos.blockSignals(False)

        if self._lista_manifestos.count() > 0:
            self._lista_manifestos.setCurrentRow(0)
        else:
            self._tabela_notas.setRowCount(0)
            self._lbl_resumo.setText("Nenhum manifesto encontrado.")

    # ------------------------------------------------------------------
    # Selecionar manifesto → carregar notas
    # ------------------------------------------------------------------

    def _ao_selecionar_manifesto(self, row: int) -> None:
        if row < 0:
            return
        manifesto_id = self._manifesto_ids.get(row)
        if manifesto_id is None:
            return
        item = self._lista_manifestos.item(row)
        nome_arquivo = item.text().split("\n")[0] if item else f"Manifesto {manifesto_id}"
        self._carregar_notas(manifesto_id, nome_arquivo)

    def _carregar_notas(self, manifesto_id: int, nome_exibido: str) -> None:
        self._tabela_notas.setSortingEnabled(False)
        self._tabela_notas.setRowCount(0)

        try:
            dados = notas_service.listar_notas_por_manifesto(manifesto_id)
        except Exception as exc:
            logger.error(f"Erro ao listar notas do manifesto {manifesto_id}: {exc}")
            dados = []

        total_frete = 0.0
        total_peso  = 0.0

        colors = theme_manager.colors

        for linha in dados:
            (
                _id_nota,
                chave_nfe,
                numero_cte,
                remetente,
                destinatario,
                origem,
                destino,
                valor_mercadoria,
                frete,
                peso,
                status,
            ) = linha

            frete = float(frete or 0)
            peso  = float(peso  or 0)
            total_frete += frete
            total_peso  += peso

            cte = numero_cte if numero_cte else (chave_nfe or "")

            row_idx = self._tabela_notas.rowCount()
            self._tabela_notas.insertRow(row_idx)

            def _item(text: str, align=Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter) -> QTableWidgetItem:
                it = QTableWidgetItem(str(text) if text else "-")
                it.setTextAlignment(align)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                return it

            _right = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter

            self._tabela_notas.setItem(row_idx, _COL_CTE,       _item(cte))
            self._tabela_notas.setItem(row_idx, _COL_REMETENTE,  _item(remetente or "-"))
            self._tabela_notas.setItem(row_idx, _COL_DEST,       _item(destinatario or "-"))
            self._tabela_notas.setItem(row_idx, _COL_ORIGEM,     _item(origem or "-"))
            self._tabela_notas.setItem(row_idx, _COL_DESTINO,    _item(destino or "-"))
            self._tabela_notas.setItem(row_idx, _COL_FRETE,      _item(formatar_moeda(frete),  _right))
            self._tabela_notas.setItem(row_idx, _COL_PESO,       _item(formatar_peso(peso),    _right))

            # Status com cor
            status_item = _item(status or "-", Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter)
            cor_status = {
                "Disponível": colors.get("success", "#22C55E"),
                "Em viagem":  colors.get("warning", "#F59E0B"),
                "Entregue":   colors.get("info",    "#3B82F6"),
            }.get(status, colors.get("text_tertiary", "#94A3B8"))
            status_item.setForeground(
                __import__("PySide6.QtGui", fromlist=["QColor"]).QColor(cor_status)
            )
            self._tabela_notas.setItem(row_idx, _COL_STATUS, status_item)

        self._tabela_notas.setSortingEnabled(True)

        qtd = len(dados)
        resumo = (
            f"{nome_exibido}   •   "
            f"Notas: {qtd}   •   "
            f"Frete Total: {formatar_moeda(total_frete)}   •   "
            f"Peso Total: {formatar_peso(total_peso)}"
        )
        self._lbl_resumo.setText(resumo)

    # ------------------------------------------------------------------
    # Importar manifesto
    # ------------------------------------------------------------------

    def _importar_manifesto(self) -> None:
        caminho, _ = QFileDialog.getOpenFileName(
            self,
            "Selecionar Manifesto TXT",
            "",
            "Arquivos TXT (*.txt);;Todos os arquivos (*.*)",
        )
        if not caminho:
            return

        self._btn_importar.setEnabled(False)
        self._btn_importar.setText("Importando…")

        self._worker = _ImportWorker(caminho)
        self._worker.concluido.connect(self._ao_importar_concluido)
        self._worker.erro.connect(self._ao_importar_erro)

        t = threading.Thread(target=self._worker.run, daemon=True)
        t.start()

    def _ao_importar_concluido(self, resultado: dict) -> None:
        self._btn_importar.setEnabled(True)
        self._btn_importar.setText("＋ Importar Manifesto")

        QMessageBox.information(
            self,
            "Importação Concluída",
            (
                f"Arquivo: {resultado.get('arquivo', '-')}\n\n"
                f"Notas encontradas:  {resultado.get('encontradas', 0)}\n"
                f"Notas salvas:       {resultado.get('salvas', 0)}\n"
                f"Notas duplicadas:   {resultado.get('duplicadas', 0)}"
            ),
        )
        self._carregar_manifestos()

    def _ao_importar_erro(self, mensagem: str) -> None:
        self._btn_importar.setEnabled(True)
        self._btn_importar.setText("＋ Importar Manifesto")

        QMessageBox.critical(self, "Erro ao Importar Manifesto", mensagem)

    # ------------------------------------------------------------------
    # Apagar manifesto
    # ------------------------------------------------------------------

    def _apagar_manifesto(self) -> None:
        row = self._lista_manifestos.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Atenção", "Selecione um manifesto para apagar.")
            return

        manifesto_id = self._manifesto_ids.get(row)
        if manifesto_id is None:
            return

        item = self._lista_manifestos.item(row)
        nome_exibido = item.text().split("\n")[0] if item else f"Manifesto {manifesto_id}"

        resposta = QMessageBox.question(
            self,
            "Apagar Manifesto",
            (
                f"Deseja apagar este manifesto?\n\n{nome_exibido}\n\n"
                "Todas as notas desse manifesto também serão apagadas."
            ),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if resposta != QMessageBox.StandardButton.Yes:
            return

        try:
            notas_service.apagar_manifesto(manifesto_id)
        except Exception as exc:
            QMessageBox.critical(self, "Erro ao Apagar Manifesto", str(exc))
            return

        QMessageBox.information(self, "Sucesso", "Manifesto apagado com sucesso!")
        self._tabela_notas.setRowCount(0)
        self._lbl_resumo.setText("Selecione um manifesto para visualizar as notas.")
        self._carregar_manifestos()
