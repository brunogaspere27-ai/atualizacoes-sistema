# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[r'C:/Users/bruno/OneDrive/Desktop/atualizaçao sistema/CW_TRANSPORTADORA atualizado'],
    binaries=[],
    datas=[
        ('assets', 'assets'),
        ('config', 'config'),
        ('telas', 'telas'),
        ('services', 'services'),
        ('utils', 'utils'),
        ('models', 'models'),
        ('migrations', 'migrations'),
        ('versao.json', '.'),
        ('configuracoes.json', '.'),
    ],
    hiddenimports=[
        'customtkinter',
        'PIL',
        'PIL._tkinter_finder',
        'sqlite3',
        'requests',
        'matplotlib',
        'numpy',
        'reportlab',
        'loguru',
        'psycopg2',
        'dotenv',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='CW_Transportadora',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=r'C:/Users/bruno/OneDrive/Desktop/atualizaçao sistema/CW_TRANSPORTADORA atualizado/assets/logo.ico',
)
