# CW Transportadora — Sistema de Gestão Logística

Sistema desktop (Python + CustomTkinter) para gestão de transportes: controle
de fretes, notas fiscais, viagens, frota, financeiro e relatórios. Usa SQLite
local, com sincronização opcional (offline-first) para um banco Supabase.

**Versão atual:** ver `versao.json`
**Status:** Produção

## Funcionalidades

- **Notas fiscais** — importação de manifestos TXT, controle de status
  (Disponível, Em viagem, Entregue), filtros por período.
- **Viagens** — criação com múltiplas notas, validação de capacidade do
  caminhão, cálculo automático de peso e frete, finalização com retorno.
- **Frota** — cadastro de caminhões, abastecimentos, manutenções, motoristas.
- **Financeiro** — contas a pagar/receber, transferências SP → Cascavel.
- **RH** — funcionários, folha de pagamento, salários e horas extras.
- **Relatórios** — dashboard com KPIs em tempo real, ranking de clientes, top
  destinos, exportação em PDF, gráficos financeiros e operacionais.
- **Sincronização** — fila offline-first (`sync_log`) sincronizada com
  Supabase quando configurado; funciona 100% localmente sem ele.

## Instalação (desenvolvimento)

Pré-requisitos: Python 3.10+ e, no Windows, Tcl/Tk (já incluso no instalador
oficial do Python).

```bash
git clone <url-do-repositorio>
cd CW_TRANSPORTADORA

python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Linux/Mac

pip install -r requirements.txt
cp .env.example .env           # edite com suas credenciais, se for usar Supabase

python main.py
```

No primeiro boot, se ainda não existir um usuário mestre, o sistema cria um
automaticamente com uma **senha gerada aleatoriamente** (nunca fica hardcoded
no código). Essa senha é mostrada em um diálogo único e também gravada em
`PRIMEIRO_ACESSO_LEIA_E_APAGUE.txt` na pasta de dados do sistema — anote-a e
apague o arquivo. O login exigirá a troca dessa senha imediatamente.

### Ferramentas de desenvolvimento

```bash
pip install -r requirements-dev.txt
pre-commit install             # ou: scripts/install_dev_tools.ps1 no Windows
pytest                          # roda a suíte de testes
```

O repositório inclui um workflow de CI (`.github/workflows/ci.yml`) que roda
lint e testes a cada push/PR.

## Configuração: `.env` vs `configuracoes.json`

O sistema tem duas fontes de configuração, com papéis diferentes:

| Fonte | Papel | Exemplos de chave |
|---|---|---|
| `.env` | Valores de ambiente/instalação, raramente alterados pela UI | `SUPABASE_URL`, `INTERVALO_SYNC_SEGUNDOS` |
| `configuracoes.json` | Preferências de negócio editadas pela tela "Configurações" | `empresa`, `cnpj`, `cidade`, `meta_lucro`, `tema` |

Quando a mesma informação existe nos dois formatos (empresa, CNPJ, cidade,
metas financeiras etc.), **`configuracoes.json` sempre tem prioridade** — o
valor do `.env` só é usado como fallback inicial, antes da primeira vez que o
usuário salva algo pela tela de Configurações. `SUPABASE_URL` e
`INTERVALO_SYNC_SEGUNDOS` só existem no `.env`, sem equivalente no JSON.
Detalhes de implementação estão documentados no topo de `config/settings.py`.

Exemplo de `.env`:

```env
SUPABASE_URL=postgresql://usuario:senha@host:5432/postgres?sslmode=require
INTERVALO_SYNC_SEGUNDOS=60
EMPRESA=CW TRANSPORTADORA
CIDADE=Cascavel
UF=PR
META_LUCRO=10000
```

## Estrutura do projeto

```
CW_TRANSPORTADORA/
├── main.py                  # Ponto de entrada da aplicação (App/CTk root)
├── config/                  # Configurações centralizadas (settings.py)
├── telas/                   # Camada de interface (uma tela por arquivo)
├── services/                # Regras de negócio, desacopladas da UI
├── utils/                   # Acesso a dados (database.py), sync, importador, logger
├── migrations/              # Migrações incrementais do schema SQLite
├── testes/                  # Suíte de testes (pytest)
├── scripts/                 # Scripts auxiliares de dev/ops (PowerShell/Python)
├── docs/                    # Guias técnicos (sync, atualizações, release)
├── assets/                  # Imagens e recursos estáticos
├── instalador.iss           # Script do Inno Setup para gerar o instalador
├── release.py               # Automação de release (versão + build + instalador)
├── requirements.txt         # Dependências de produção
└── requirements-dev.txt     # Dependências de desenvolvimento (lint, testes)
```

Pastas geradas em tempo de execução (não versionadas): `backup_dados/`,
`relatorios_gerados/`, `build/`, `dist/`, `release/`.

## Arquitetura

- **`telas/`** contém apenas UI (CustomTkinter/Tkinter) — não tem lógica de
  negócio nem SQL direto.
- **`services/`** contém as regras de negócio (ex.: `ViagemService`,
  `DashboardService`) e é o que `telas/` chama. Pode ser testado sem UI.
- **`utils/database.py`** é a camada de acesso a dados (SQLite). A maioria das
  funções aceita um parâmetro opcional `conn`: quando omitido, a função abre e
  fecha sua própria conexão (comportamento simples, ideal para chamadas
  isoladas); quando uma função orquestradora precisa combinar várias consultas
  na mesma operação lógica (ex.: `DashboardService.carregar_dashboard`), ela
  abre uma única conexão e a passa adiante, evitando conexões redundantes sem
  introduzir um pool de conexões (desnecessário para SQLite).
- **Autenticação** (`services/auth_service.py`): PBKDF2-HMAC-SHA256 com 600k
  iterações, salt por usuário, bloqueio após 5 tentativas, comparação
  constante (`hmac.compare_digest`).
- **Sincronização** (`utils/sync.py`): offline-first — toda escrita grava uma
  entrada em `sync_log`; quando há conexão com o Supabase configurado, a fila
  é processada em background.

## Segurança

- Nenhuma senha fica hardcoded no código: o usuário mestre é criado com senha
  aleatória no primeiro boot e a troca é obrigatória no primeiro login.
- Hash de senha com PBKDF2-HMAC-SHA256 (600.000 iterações) + salt único por
  usuário; comparação com `hmac.compare_digest` (resistente a timing attack).
- Credenciais de banco/nuvem ficam em `.env`, nunca comitadas (ver
  `.gitignore`); use `.env.example` como modelo.

## Backup e restauração

- **Automático:** criado a cada abertura/fechamento do sistema, em
  `backup_dados/automatico/`; mantém os últimos 20 backups.
- **Manual:** opção "Zerar / Preparar Distribuição" oferece backup completo
  antes de limpar os dados.
- **Restauração:** copie o `.db` desejado para a pasta de dados do sistema
  (`%LOCALAPPDATA%\CW Transportadora\` no Windows).

## Testes

```bash
pytest                         # suíte completa
pytest -m "not integration"    # só testes unitários (mais rápidos)
```

Alguns testes de UI (`test_telas_smoke.py`, `test_criar_viagem_selection.py`,
`test_update_service.py`) exigem Tcl/Tk instalado — sem isso o pytest falha ao
importar o módulo, o que é uma limitação do ambiente, não um bug do sistema.

## Troubleshooting

- **Erro de conexão com Supabase:** confira `SUPABASE_URL` no `.env` e a
  conexão com a internet.
- **Erro ao importar manifesto:** confirme o formato/encoding (UTF-8) do TXT.
- **Sincronização travada:** veja `docs/guia_configuracao_sync.md`.

## Documentação adicional

- [`docs/guia_configuracao_sync.md`](docs/guia_configuracao_sync.md) — configurar sincronização com Supabase.
- [`docs/guia_configuracao_http.md`](docs/guia_configuracao_http.md) — sistema de atualizações via HTTP/HTTPS.
- [`docs/relatorio_tecnico_atualizacoes.md`](docs/relatorio_tecnico_atualizacoes.md) — sistema próprio de distribuição de versões.
- [`docs/release.md`](docs/release.md) — processo de build e geração do instalador (`release.py`).

## Licença

Sistema proprietário da CW Transportadora. Ver histórico de versões em
`versao.json`.
