# -*- mode: python ; coding: utf-8 -*-

from PyInstaller.utils.hooks import collect_submodules

hiddenimports = []
hiddenimports += collect_submodules("psycopg2")
hiddenimports += collect_submodules("customtkinter")
hiddenimports += collect_submodules("PIL")
hiddenimports += collect_submodules("matplotlib")
hiddenimports += collect_submodules("reportlab")
hiddenimports += collect_submodules("loguru")
hiddenimports += collect_submodules("dotenv")
hiddenimports += collect_submodules("requests")
hiddenimports += collect_submodules("telas")
hiddenimports += collect_submodules("services")
hiddenimports += collect_submodules("utils")
hiddenimports += collect_submodules("config")
hiddenimports += [
    "tkinter",
    "tkinter.messagebox",
    "tkinter.simpledialog",
    "tkinter.filedialog",
    "tkinter.ttk",
    "sqlite3",
    "matplotlib.backends.backend_tkagg",
]

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[],
    datas=[
        ("assets", "assets"),
    ],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="CW Transportadora",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=["assets\\logo.ico"],
)
